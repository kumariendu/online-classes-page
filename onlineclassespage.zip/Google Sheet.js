
const scriptURL = "https://script.google.com/macros/s/AKfycbxoAR9BefZ2uMEsHLu3H1rAU2k9xp4BnNuIRnC-3oNK0-LpriLWyy2JHYfYca8YQePXvw/exec"; // Replace with your new script URL

const form = document.forms["contact-form"];

form.addEventListener("submit", (e) => {
  e.preventDefault();
  
  fetch(scriptURL, { method: "POST", body: new FormData(form) })
    .then((response) => response.json())
    .then((data) => {
      if (data.result === "success") {
        alert("Thank you! Form is submitted");
        form.reset();
      } else {
        alert("Error: " + data.error);
      }
    })
    .catch((error) => console.error("Error!", error));
});


